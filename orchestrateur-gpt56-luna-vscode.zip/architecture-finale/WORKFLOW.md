# Workflow

## 0. Préflight manager

Transformer la demande en :
- goal ;
- in_scope / out_of_scope ;
- acceptance criteria ;
- protected files ;
- required checks ;
- contraintes de dépendances.

Si l'ambiguïté change substantiellement le scope ou le risque, demander une clarification. Sinon choisir une stratégie et avancer.

## 1. Décomposition

Créer le minimum d'unités de travail nécessaires.

Unité Coder indépendante uniquement si :
- son résultat est identifiable ;
- ses fichiers/responsabilités ne chevauchent pas ceux d'un autre writer ;
- elle peut être intégrée/reviewée séparément.

## 2. Délégation Coder

Pour chaque task : envoyer le contrat complet.

Le Coder retourne : COMPLETED ou SCOPE_BLOCKED, plus ses fichiers revendiqués et les éléments non résolus.

## 3. Fan-in

Le manager attend les writers requis. Avant review finale, vérifier qu'aucune tâche obligatoire n'est manquante ou bloquée.

## 4. Scope gate

Déléguer au Tester l'audit Git :
- `git status --porcelain` ;
- `git diff --name-only` ;
- autres commandes read-only utiles.

Si fichiers hors scope : `FIX_REQUIRED` avant toute validation finale.

## 5. Review + tests

Lorsque l'état est cohérent :
- lancer Reviewer(s) ;
- lancer Tester(s) pour `required_checks`.

Peuvent être parallèles si leurs commandes/ressources ne se gênent pas.

## 6. Décision

### DONE
Tous les critères applicables vérifiés, scope PASS, aucune finding blocking, required checks PASS.

### FIX_REQUIRED
Correction claire et dans le scope.

### BLOCKED
Dépendance externe, extension de scope, conflit ou impossibilité nécessitant une décision.

### UNVERIFIED
Résultat plausible mais une preuve requise n'a pas pu être obtenue.

### PARTIAL
Une partie utile est terminée mais la demande complète ne l'est pas.

## 7. Correction

Le manager fournit au Coder uniquement :
- findings à corriger ;
- fichiers concernés ;
- critères affectés ;
- scope inchangé ou explicitement révisé.

Puis relance les vérifications affectées.

## 8. Limite de boucle

Recommandation d'architecture : **2 cycles de correction** par défaut, puis `BLOCKED` si le même problème persiste ou si le scope devient instable.

Ce nombre est une politique locale **INFÉRÉE**, pas une limite officielle OpenAI/VS Code. L'ajuster au repo.
