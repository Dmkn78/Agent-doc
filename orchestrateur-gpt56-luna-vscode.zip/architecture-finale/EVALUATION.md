# Évaluation Luna / Terra

## Données officielles utiles

### Coding
| Évaluation officielle | Luna | Terra |
|---|---:|---:|
| Artificial Analysis Coding Agent Index | 74,6 | 77,4 |
| SWE-Bench Pro | 62,7 | 63,4 |
| DeepSWE v1.1 | 67,2 | 69,6 |
| Terminal-Bench 2.1 | 84,7 | 87,4 |

### Agent/tool use
| Évaluation | Luna | Terra |
|---|---:|---:|
| Agents' Last Exam | 50,3 | 50,4 |
| AutomationBench | 14,9 | 15,2 |
| Toolathlon | 53,4 | 53,1 |

### Self-improvement / debugging
| Évaluation | Luna | Terra |
|---|---:|---:|
| Internal Research Debugging | 50,8 | 67,8 |
| KernelGen | 22,4 | 49,2 |
| PostTrainBench | 29,6 | 51,5 |
| RSI Index | 41,9 | 56,3 |

### Long context
| Évaluation | Luna | Terra |
|---|---:|---:|
| MRCR 256K–512K | 41,3 | 89,6 |
| MRCR 512K–1M | 41,3 | 72,5 |
| GraphWalks 256K | 81,3 | 76,9 |
| GraphWalks 1M | 51,2 | 71,2 |

## Scorecard manager

| Dimension | Conclusion | Statut |
|---|---|---|
| compréhension / décomposition | Luna viable ; Terra probablement plus robuste sur complexité | INFÉRÉ |
| scope discipline | doit être architecturale, pas confiée au modèle | NON DOCUMENTÉ modèle |
| délégation VS Code | mécanisme disponible via subagents/custom agents | DOCUMENTÉ VSCODE |
| multi-agent parallelism | disponible ; writers partagent le workspace dans une session | DOCUMENTÉ VSCODE |
| self-correction | Terra a un avantage officiel important | DOCUMENTÉ OPENAI |
| tool use | proches ; pas d'avantage Terra universel | DOCUMENTÉ OPENAI |
| long context | Terra plus robuste sur plusieurs grandes tailles ; Luna a une exception 256K | DOCUMENTÉ OPENAI |
| coding | Terra légèrement/measurably supérieur | DOCUMENTÉ OPENAI |
| review quality spécifique | pas de benchmark manager/reviewer VS Code dédié trouvé | NON DOCUMENTÉ |
| coût API | Luna 0,20/0,02/1,20 ; Terra 2/0,20/12 $ par 1M | DOCUMENTÉ OPENAI |
| latence chiffrée | non trouvée dans les sources retenues | NON DOCUMENTÉ |

## Recommandation

### Qualité prioritaire
**Terra manager + Luna workers.**

C'est le seul changement de modèle que les données officielles rendent réellement intéressant : le manager concentre debugging, réconciliation et état global, précisément là où plusieurs évaluations favorisent fortement Terra.

### Coût prioritaire / contrainte Luna
**Luna manager + Luna workers** reste viable avec cette architecture. Les guardrails sont alors non négociables : contexte compact, writer sans ownership global, review indépendante, Tester, Git scope gate, cycles bornés.

## Sol

Sol n'est pas une architecture cible. Il est utilisé uniquement comme point de comparaison de famille. Aucun prompt n'est présenté comme transformant Luna en Sol.
