# Architecture

## Topologie recommandée

```text
                         User request
                              │
                              ▼
                    Orchestrator Manager
               task / scope / dependencies
                              │
               ┌──────────────┴──────────────┐
               │                             │
               ▼                             ▼
          Coder instance A              Coder instance N
        (scope A, writer)              (scope N, writer)
               │                             │
               └──────────────┬──────────────┘
                              ▼
                            fan-in
                              │
                     deterministic scope gate
                      (Tester + Git state)
                              │
               ┌──────────────┴──────────────┐
               ▼                             ▼
          Reviewer(s)                    Tester(s)
           read-only                 execute + evidence
               │                             │
               └──────────────┬──────────────┘
                              ▼
                    Orchestrator Manager
                              │
          DONE | FIX_REQUIRED | BLOCKED | UNVERIFIED | PARTIAL
```

## Pourquoi pas plus d'agents

- **Pas de Planner distinct** : décomposition et dépendances sont le cœur du manager.
- **Pas de Router distinct** : le manager peut choisir dynamiquement Coder/Reviewer/Tester ; un routeur XOR n'apporte pas de contrôle déterministe utile ici.
- **Pas de Synthesizer** : le fan-in et le verdict restent au manager.
- **Pas de Security Reviewer par défaut** : ajouter un reviewer spécialisé uniquement si le projet a une vraie classe de risques qui le justifie.

## Arborescence à recréer

```text
repo/
├── .github/
│   └── agents/
│       ├── orchestrator.agent.md
│       ├── coder.agent.md
│       ├── reviewer.agent.md
│       └── tester.agent.md
├── .vscode/
│   └── settings.json                 # modifier/merger, ne pas écraser
├── <emplacement réel des skills>/
│   ├── coding/.../SKILL.md           # EXISTANT, ne pas recréer
│   ├── coding-rules/.../SKILL.md     # EXISTANT, ne pas recréer
│   └── coding-quality/.../SKILL.md   # EXISTANT, ne pas recréer
└── .github/hooks/                    # OPTIONNEL, Preview VS Code
```

## Invariants

1. Le manager ne modifie pas le code et n'exécute pas de commande.
2. Les workers n'invoquent aucun subagent.
3. Le scope vient du manager et n'est jamais étendu par un worker.
4. Le writer n'est jamais l'unique reviewer de son travail.
5. Le Tester est la source des résultats d'exécution.
6. Git est la source de vérité pour les fichiers réellement modifiés.
7. Un refactor hors tâche est une proposition, pas une modification.
8. `DONE` est un verdict fondé sur preuves, pas une impression.
9. Le contexte remonté au manager contient conclusions et preuves, pas les longues explorations internes.
10. Hooks et sandbox renforcent le système mais ne remplacent pas review/tests/Git.

## Modèles

### Cible Luna
- Orchestrator : GPT-5.6 Luna.
- Coder / Reviewer / Tester : GPT-5.6 Luna.
- Reasoning manager : niveau maximal réellement visible dans VS Code.

### Variante qualité
- Orchestrator : GPT-5.6 Terra.
- Workers : GPT-5.6 Luna.
- Intérêt : meilleur signal officiel sur debugging/self-improvement et plusieurs évaluations long-context.
- Coût API : Terra ~10× Luna aux tarifs courants ; vérifier le coût propre à Copilot/VS Code si différent.
