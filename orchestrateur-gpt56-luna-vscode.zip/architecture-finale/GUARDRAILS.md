# Guardrails

## G1 — Scope contract

Chaque writer reçoit `allowed_files` et `protected_files`.

Si une correction exige un fichier non autorisé : `SCOPE_BLOCKED`. Le worker n'étend jamais lui-même le scope.

## G2 — Tool boundaries

Le manager n'a pas edit/execute. Reviewer n'a pas edit. Tester n'a pas edit. Workers n'ont pas `agent`.

## G3 — Git gate

Avant DONE : comparer l'état Git observé au scope.

La vue Changes du chat n'est pas suffisante pour des writes via terminal.

## G4 — Independent verification

Coder ≠ Reviewer ≠ Tester ≠ décision finale.

## G5 — Evidence over claims

PASS exige une exécution observée. `NOT_RUN` et `NOT_AVAILABLE` sont des états légitimes et doivent rester visibles.

## G6 — No opportunistic refactor

Une amélioration hors scope va dans `out_of_scope_suggestions`.

## G7 — Bounded correction

Correction courte, findings précis, nouvelle vérification. Après stagnation, BLOCKED au lieu de dériver.

## G8 — Parallel writer rule

Pas de writers simultanés sur fichiers ou contrats partagés. Pour isolation forte, utiliser sessions/worktrees séparés.

## G9 — Permission level

Default Approvals. Pas de Bypass/Autopilot comme défaut.

## G10 — Sandbox

Activer sur plateformes supportées. Bloquer l'élévation hors sandbox (`allowUnsandboxedCommands: false`) pour les runs stricts.

## G11 — Hooks optionnels

Les hooks `PreToolUse` peuvent `deny`/`ask` une invocation et journaliser les calls. Comme les hooks sont Preview, ils renforcent mais ne garantissent pas le système.

Usage recommandé si accepté :
- protéger `.github/agents/`, `.github/hooks/`, `.env`, configurations sensibles ;
- bloquer commandes destructrices ;
- audit append-only non tracké.

Ne pas laisser l'agent modifier silencieusement le script de hook qui le contrôle.
