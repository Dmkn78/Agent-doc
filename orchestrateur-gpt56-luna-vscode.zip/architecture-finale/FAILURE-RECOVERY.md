# Failure recovery

| Échec | Signal | Prévention | Récupération |
|---|---|---|---|
| scope creep | fichier hors `allowed_files` | contrat + Git gate | revert ciblé, redéléguer |
| refactor opportuniste | diff sans lien acceptance criteria | règle proposal-only + reviewer | supprimer le changement, garder suggestion |
| dépendance hors scope | Coder retourne SCOPE_BLOCKED | scope explicite | manager décide extension ou BLOCKED |
| faux DONE | aucune preuve de checks | completion gate | UNVERIFIED puis Tester |
| test inventé | aucun command/output associé | Tester seul source de PASS | invalider claim, exécuter réellement |
| test impossible | outil/commande absent | required_checks explicites | NOT_AVAILABLE + décision manager |
| review complaisante | bug persistant / findings faibles | reviewer contexte indépendant | second Reviewer ou humain |
| conflit writers | même fichier/contrat | sérialisation/worktrees | stopper, restaurer, intégrer un par un |
| changement terminal invisible dans chat Changes | Git détecte un fichier inattendu | Git gate | analyser/revert, revoir command policy |
| boucle de fix | même erreur revient | cycles bornés | BLOCKED + diagnostic humain/manager |
| contexte saturé | dérive/coût/contradictions | subagents + progressive context | `/compact` ou nouvelle session avec état vérifié |
| skill contradictoire | règles incohérentes | audit des SKILL.md | désigner source canonique, supprimer duplication |
| hook cassé | hook bloque tout ou ne voit rien | hook non critique, Preview | désactiver, revenir approvals+Git |
| sandbox bloque check légitime | command fail restriction | config path/network explicite | autoriser précisément ou NOT_AVAILABLE ; pas d'élévation silencieuse |
