# Permissions et least privilege

## Matrice

| Agent | agent | read | search | edit | execute | Subagents |
|---|---:|---:|---:|---:|---:|---|
| Orchestrator | oui | oui | oui | non | non | Coder, Reviewer, Tester uniquement |
| Coder | non | oui | oui | oui | non | aucun |
| Reviewer | non | oui | oui | non | non | aucun |
| Tester | non | oui | oui | non | terminal ciblé | aucun |

## Pourquoi le Coder n'a pas `execute`

Le writer ne doit pas être sa propre preuve de test. Retirer `execute` :
- réduit la surface d'action ;
- empêche l'installation opportuniste de dépendances ;
- oblige le système à passer par un Tester indépendant pour les résultats d'exécution.

Si un projet impose un cycle test-driven très local chez le Coder, cette restriction peut être assouplie, mais l'independent Tester final reste obligatoire.

## VS Code — session

Configuration recommandée :
- Permission level : **Default Approvals**.
- Ne pas utiliser Bypass Approvals comme défaut.
- Ne pas utiliser Autopilot pour ce manager strict.
- Garder les subagents imbriqués désactivés.

## Terminal

Option stricte :

```json
{
  "chat.tools.terminal.enableAutoApprove": false
}
```

Ainsi chaque commande terminal nécessite une approbation, sauf comportement contrôlé par sandbox.

## Sandbox

Sur macOS/Linux/WSL2, lorsque disponible :

```json
{
  "chat.agent.sandbox.enabled": "on",
  "chat.agent.sandbox.allowNetwork": false,
  "chat.agent.sandbox.allowUnsandboxedCommands": false
}
```

Ajouter des `denyWrite` pour des dossiers sensibles si nécessaire. Les règles sandbox sont path-based, sans glob pour ces listes.

## Fichiers sensibles

Ne pas activer un « approve all edits » global. Utiliser VS Code pour demander une approbation explicite sur `.env`, `.vscode`, configuration agent/hooks et autres fichiers sensibles propres au repo.

## Limite

Auto-approval terminal est documenté comme best-effort et la détection de writes par commandes est minimale. Le sandbox + Git audit restent nécessaires pour une politique forte.
