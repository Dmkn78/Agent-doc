# Orchestrateur de coding GPT-5.6 — architecture finale

## Résultat

Architecture VS Code à quatre rôles :

1. **Orchestrator** — possède la tâche, le scope, la délégation, le fan-in et le verdict.
2. **Coder** — écrit du code dans un sous-scope explicite.
3. **Reviewer** — read-only, produit des findings indépendants.
4. **Tester** — exécute les checks et audite l'état Git, sans outil d'édition.

Le design cible fonctionne avec **GPT-5.6 Luna manager + workers Luna**. L'analyse officielle montre toutefois un avantage suffisamment important de **GPT-5.6 Terra comme manager** sur plusieurs évaluations de debugging/self-improvement et long-context pour le recommander lorsque la qualité d'orchestration prime sur le coût. Les workers peuvent rester Luna.

## Règle de modèle dans VS Code

Ne pas inventer `max`, `xhigh` ou un identifiant de modèle.

- Manager Luna : sélectionner **GPT-5.6 Luna** dans le model picker.
- Reasoning : `NIVEAU_MAXIMAL_DISPONIBLE À CONFIGURER SELON VSCODE`.
- Le champ `model:` est volontairement omis des templates de base : le modèle sélectionné dans VS Code est alors utilisé.
- Variante Terra : sélectionner Terra pour le manager, puis configurer explicitement chaque worker sur l'entrée Luna réellement proposée par l'éditeur Customizations.

## Point bloquant réel

Les fichiers des skills `coding`, `coding-rules`, `coding-quality` n'étaient pas présents dans le repository accessible à cette session. Ils n'ont donc **pas été inventés**.

Avant mise en production sur l'autre PC :
- localiser leurs `SKILL.md` ;
- lire leurs responsabilités ;
- remplir la matrice dans `AGENTS.md` ;
- configurer `chat.agentSkillsLocations` si leur répertoire n'est pas découvert automatiquement.

## Fichiers

- `ARCHITECTURE.md` — topologie et choix de design.
- `ORCHESTRATOR.md` — prompt final du manager.
- `AGENTS.md` — rôles workers et skills.
- `PERMISSIONS.md` — least privilege, approvals, sandbox.
- `WORKFLOW.md` — demande → DONE/FIX/BLOCK.
- `GUARDRAILS.md` — scope, Git, hooks, stop conditions.
- `OBSERVABILITY.md` — preuves et audit.
- `FAILURE-RECOVERY.md` — taxonomie et récupération.
- `EVALUATION.md` — Luna vs Terra.
- `MANUAL-REBUILD.md` — procédure compacte de reconstruction manuelle.
