# Observabilité

## Trace opérationnelle minimale

À la fin d'une tâche, le manager doit pouvoir produire :

```yaml
task:
  id: T-001
  goal: ...
  scope: ...
delegations:
  - agent: Coder
    task_id: T-001-A
    status: COMPLETED
changed_files_observed: []
review:
  verdict: PASS | FINDINGS
  findings: []
checks:
  - command: ...
    status: PASS | FAIL | NOT_RUN | NOT_AVAILABLE
    exit_code: null
scope_audit: PASS | FAIL | UNVERIFIED
fix_cycles: 0
unverified: []
final_status: DONE | FIX_REQUIRED | BLOCKED | UNVERIFIED | PARTIAL
```

## Sources de preuve

1. **Subagent details** : VS Code expose prompt, tool calls et résultat du subagent.
2. **Terminal** : commande + output + exit status observable.
3. **Git** : `status` / `diff` pour état réel.
4. **Reviewer** : findings structurés avec fichier/ligne/preuve.
5. **Hooks** : audit supplémentaire optionnel.
6. **Session history / peer chats** : historique opérationnel.

## Ne pas stocker

- chaîne de pensée privée ;
- reasoning tokens ;
- secrets ;
- logs bruts sans utilité ;
- données de test sensibles non nécessaires.

## Règle

L'observabilité répond à « qu'est-ce qui a été demandé, exécuté et vérifié ? », pas « quelle pensée interne exacte le modèle a-t-il eue ? ».
