# 01 — GPT-5.6 Luna comme manager

## Conclusion

Luna peut tenir le rôle de manager **si le système externalise les fonctions où un échec est coûteux** : scope enforcement, review, tests, diff audit et arrêt. Il ne faut pas lui demander d'être simultanément planner, writer, reviewer et preuve de correction.

## Ce que Luna doit connaître

À chaque tâche, contexte minimal du manager :

1. mission utilisateur normalisée ;
2. état courant du projet utile à cette mission ;
3. architecture/contraintes nécessaires à la décision ;
4. scope autorisé et fichiers protégés ;
5. acceptance criteria / définition de DONE ;
6. carte des sous-tâches et dépendances ;
7. agents disponibles et limites de leurs outils ;
8. sorties structurées des subagents ;
9. preuves de review/tests/scope audit ;
10. blocages et éléments non vérifiés.

## Ce qu'il ne faut pas charger inutilement

- historique complet des explorations de chaque Coder ;
- logs bruts volumineux si un Tester peut renvoyer les erreurs utiles ;
- règles de coding déjà présentes dans des skills ;
- documentation entière du repo sans lien avec la tâche ;
- anciennes tentatives corrigées et obsolètes ;
- chaîne de pensée privée ;
- multiples copies des mêmes interdictions.

## Pourquoi ce cadrage est nécessaire

**DOCUMENTÉ** — OpenAI montre des écarts significatifs Luna/Terra sur plusieurs évaluations de self-debugging et de long-context.  
**INFÉRÉ** — Un manager Luna est donc plus fiable si son travail consiste à orchestrer un état compact et des preuves produites par d'autres mécanismes que s'il doit retenir/reconstruire toute l'histoire d'une tâche.

## Reasoning dans VS Code

OpenAI API documente jusqu'à `max`, mais la documentation VS Code consultée ne garantit pas que Luna expose `xhigh` ou `max` dans le picker.

Configuration retenue :

`NIVEAU_MAXIMAL_DISPONIBLE À CONFIGURER SELON VSCODE`

Choisir le niveau le plus élevé réellement visible pour le modèle Luna dans le model picker de la session manager. Ne pas écrire un nom de niveau non proposé.
