# 03 — Décomposition et délégation

## Décomposition du manager

Le manager transforme :

`demande → problème → unités de travail → dépendances → scopes → délégations → fan-in → vérification → décision`

Il ne doit pas imposer un pipeline artificiel si une tâche simple peut être traitée par un seul Coder puis review/test.

## Test de décomposabilité

Créer plusieurs tâches uniquement si au moins une condition est vraie :
- scopes de fichiers clairement séparables ;
- responsabilités techniques indépendantes ;
- recherche/analyse peut être isolée de l'implémentation ;
- plusieurs revues indépendantes apportent des perspectives distinctes ;
- suites de tests indépendantes peuvent être lancées sans conflit.

Sinon, garder une seule unité de travail.

## Contrat minimal de délégation

```yaml
task_id: T-01
goal: résultat observable à obtenir
scope: ce qui est inclus et exclu
allowed_files: chemins/globs autorisés
protected_files: chemins interdits
inputs: références nécessaires
constraints: contraintes non automatisées
acceptance_criteria: critères binaires/observables
required_checks: checks à exécuter par Tester
expected_output: schéma de retour
```

## Règles

- Le manager fixe le scope ; le subagent ne l'étend jamais seul.
- Si une dépendance hors scope est nécessaire : retour `SCOPE_BLOCKED` avec chemin et raison.
- Une suggestion hors scope est séparée de l'implémentation.
- Le subagent étant stateless dans VS Code, le contrat doit être autosuffisant dès l'invocation.
- Le parent ne délègue qu'aux agents explicitement autorisés.

## Fan-in

Le manager ne concatène pas aveuglément les réponses. Il réconcilie :
1. tâches terminées ou bloquées ;
2. fichiers revendiqués modifiés ;
3. conflits potentiels ;
4. findings ;
5. résultats de checks ;
6. état Git réel ;
7. critères non couverts.
