# 07 — Parallélisme

## Ce qui est sûr à paralléliser

- plusieurs reviewers read-only ;
- analyses/recherches de code indépendantes ;
- tests indépendants qui n'écrivent pas dans les mêmes ressources ;
- coders sur scopes de fichiers disjoints **si** les modules n'ont pas de contrat partagé modifié.

## Ce qui ne doit pas être parallélisé dans le même workspace

- deux writers sur le même fichier ;
- deux writers modifiant une même API/interface/schema ;
- migration de DB + code dépendant de la même migration sans ordre défini ;
- génération de lockfile ou manifest partagé par plusieurs writers ;
- opérations Git concurrentes.

## Limite VS Code importante

La documentation VS Code indique que les chats/subagents d'une même session Agent Host partagent le dossier/worktree. L'isolation de contexte du subagent n'est donc pas une isolation de fichiers.

**Conséquence** : dans une seule session manager, la stratégie conservatrice est de sérialiser les writers à risque.

## Worktrees

Pour des tâches d'écriture vraiment parallèles : sessions Agent Host séparées sur des Git worktrees isolés, puis intégration explicite.

**NON DOCUMENTÉ** : qu'un custom agent parent puisse automatiquement créer et administrer ces worktree sessions comme des subagents ordinaires avec les mêmes garanties. Ne pas prétendre que le manager le fait automatiquement.

## Fan-in de worktrees

1. chaque branche/worktree doit fournir son diff + tests locaux ;
2. intégrer une branche à la fois ;
3. résoudre conflits explicitement ;
4. relancer les checks après intégration ;
5. faire une review finale de l'état intégré.
