# 04 — Contrôle du scope

## Objectif

Empêcher qu'une consigne textuelle soit l'unique protection contre des modifications hors périmètre.

## Défense en profondeur

### 1. Ownership
Le manager crée `allowed_files` et `protected_files`.

### 2. Tool restriction
- manager : pas d'edit/execute ;
- reviewer : read/search seulement ;
- tester : pas d'edit ;
- coder : edit mais pas agent ; execute retiré par défaut.

### 3. Approvals
Ne pas utiliser global auto-approve / Bypass / Autopilot par défaut. Garder approbation humaine pour les actions sensibles.

### 4. Sandbox
Pour l'exécution de commandes, activer le sandbox VS Code lorsqu'il est disponible. Un worktree n'est pas une frontière de sécurité OS.

### 5. Git scope audit
Après l'implémentation et après les tests :

```bash
git status --porcelain
git diff --name-only
```

Le Tester compare les chemins observés à `allowed_files` / `protected_files`.

### 6. Hook optionnel
Hook `PreToolUse` : bloquer/ask sur fichiers statiquement protégés et commandes dangereuses. Fonctionnalité Preview ; ne jamais en faire le seul contrôle.

### 7. Independent review
Reviewer vérifie que le diff est nécessaire à la tâche et signale refactors opportunistes.

## Pourquoi Git est le gate principal

La vue de changements du chat ne couvre pas nécessairement les fichiers changés indirectement par des commandes terminal. Git voit l'état du workspace versionné et les untracked pertinents via `status`.

## Verdict scope

- `PASS` : changed files ⊆ allowed_files et aucun protected file touché.
- `FAIL` : au moins un changement hors scope.
- `UNVERIFIED` : repo non-Git ou état impossible à déterminer.

En cas de `FAIL`, le manager ne valide pas ; il demande rollback/correction ciblée ou escalade.
