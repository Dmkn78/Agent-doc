# Agents de coding — savoir utile extrait du projet

## Principe 1 — Writer et reviewer indépendants

**Principe**  
La production et la critique ne doivent pas être le même rôle logique.

**Problème traité**  
Auto-review complaisante, justification a posteriori de ses propres choix.

**Application possible à Luna**  
Coder ne prononce jamais le verdict final. Reviewer travaille read-only et retourne des findings ; le manager décide d'un cycle de correction.

**Limite**  
Deux instances du même modèle ne garantissent pas une indépendance statistique parfaite. L'indépendance vient surtout du contexte et du rôle séparés.

**Implication pour l'architecture**  
Subagent Reviewer distinct, contexte frais, aucun outil edit.

**SOURCE_PROJET**  
- `Comment-et-quand-à-utiliser-sous-agents-IA.txt`
- `Créer-des-sous-agents-personnalisés.txt`
- `Cours-avancé-—-Loop-Agentic-Loop-Engineering.txt`

## Principe 2 — Tests déterministes comme gate

**Principe**  
Lint, typecheck, tests et build sont des évaluateurs déterministes lorsqu'ils existent.

**Problème traité**  
Le reviewer juge du style mais manque une erreur mécanique ; le writer annonce une réussite sans exécution.

**Application possible à Luna**  
Tester exécute uniquement les checks transmis dans `required_checks` et distingue PASS / FAIL / NOT_RUN / NOT_AVAILABLE.

**Limite**  
Le Tester ne doit pas inventer des commandes projet ni installer des dépendances sans autorisation.

**Implication pour l'architecture**  
Les commandes de validation sont une donnée de contexte projet, idéalement fournie par les skills/règles existants ou les scripts du repo.

**SOURCE_PROJET**  
- `Cours-avancé-—-Loop-Agentic-Loop-Engineering.txt`, exemple de boucle de correction de code.
- `guide-architecture-multi-agents.md`

## Principe 3 — Pas de refactor opportuniste

**Principe**  
Une amélioration découverte hors tâche doit être signalée, pas appliquée.

**Problème traité**  
Diff élargi, nouveaux bugs, code review plus difficile, conflit avec le scope utilisateur.

**Application possible à Luna**  
Le Coder retourne `out_of_scope_suggestions` séparément ; seuls les fichiers autorisés peuvent être modifiés.

**Limite**  
Parfois une correction exige une dépendance réelle hors scope ; elle doit remonter au manager pour redéfinition explicite, pas être forcée.

**Implication pour l'architecture**  
Tout besoin d'extension devient `SCOPE_BLOCKED` puis décision du manager/utilisateur.

**SOURCE_PROJET**  
- `Prompt-engineering-avancé.txt`
- `Cours-avancé-—-Loop-Agentic-Loop-Engineering.txt`
