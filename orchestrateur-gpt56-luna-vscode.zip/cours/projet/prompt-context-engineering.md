# Prompt et context engineering — savoir utile extrait du projet

## Principe 1 — Structurer les variables qui changent réellement la décision

**Principe**  
Nommer objectif, scope, inputs, contraintes, critères de succès et format de sortie réduit l'ambiguïté mieux qu'une personnalité ou qu'une longue prose.

**Problème traité**  
Le modèle doit deviner les frontières de la tâche et le niveau de preuve attendu.

**Application possible à Luna**  
Le contrat de délégation minimal contient `goal`, `scope`, `allowed_files`, `protected_files`, `inputs`, `constraints`, `acceptance_criteria`, `required_checks`, `expected_output`.

**Limite**  
Les affirmations quantitatives du projet sur un nombre maximal de « variables » ou un seuil de tokens ne sont pas retenues comme capacités officielles : **NON DOCUMENTÉ** dans les sources OpenAI/VS Code autorisées.

**Implication pour l'architecture**  
Contrat court et typé ; pas de duplication de la totalité du prompt manager dans chaque worker.

**SOURCE_PROJET**  
- `Prompt-engineering-avancé.txt`
- `Pourquoi-a-t-on-besoin-de-mémoire-pour-un-agent-IA.txt`

## Principe 2 — Préflight avant exécution

**Principe**  
Avant de produire ou modifier, vérifier que les données indispensables existent ; sinon retourner un blocage explicite.

**Problème traité**  
Hallucination par comblement de trous, tâche démarrée avec scope ambigu.

**Application possible à Luna**  
Le manager n'envoie pas un Coder tant qu'il n'a pas défini un scope exploitable et des critères d'acceptation. Le worker retourne `BLOCKED` s'il découvre une dépendance hors scope.

**Limite**  
Le préflight doit rester léger ; il ne doit pas devenir une deuxième implémentation du travail.

**Implication pour l'architecture**  
Ajouter un test d'entrée au manager et au contrat worker, mais laisser la stratégie d'exécution dynamique.

**SOURCE_PROJET**  
- `Prompt-engineering-avancé.txt`
- `Agentic-worflow.txt`

## Principe 3 — Ne remonter que la conclusion utile des explorations bruyantes

**Principe**  
Quand les détails intermédiaires d'une exploration ne seront pas nécessaires ensuite, les isoler et ne conserver que la conclusion opérationnelle.

**Problème traité**  
Pollution du contexte du manager par recherches, debugging et alternatives abandonnées.

**Application possible à Luna**  
Les subagents renvoient une sortie standardisée : résultat, preuves, fichiers concernés, risques, éléments non vérifiés.

**Limite**  
Les commandes `/rewind` et concepts spécifiques à Claude dans le projet ne sont pas transposés tels quels. VS Code possède ses propres sessions/subagents/compact.

**Implication pour l'architecture**  
Context minimization par délégation stateless et fan-in structuré.

**SOURCE_PROJET**  
- `gérez-les-sessions,-le-contexte-et-la-compaction-influence-vos-résultats-d'agent.txt`
- `Comment-et-quand-à-utiliser-sous-agents-IA.txt`
