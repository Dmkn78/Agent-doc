# Synthèse du savoir projet exploitable

## Corpus analysé

- `guide-architecture-multi-agents.md`
- `multi_agent_cours.pdf` — 5 pages, architecture séquentielle / séparation de rôles / anti-patterns
- `Agentic-worflow.txt`
- `Coder-des-agents-IA-etape-par-etape.txt`
- `Pourquoi-a-t-on-besoin-de-mémoire-pour-un-agent-IA.txt`
- `Claude-Code-conçoit-des-agents-IA.txt`
- `Coder-un-module-de-planification-et-de-mémoire-pour-un-agent-IA.txt`
- `Créer-des-sous-agents-personnalisés.txt`
- `gérez-les-sessions,-le-contexte-et-la-compaction-influence-vos-résultats-d'agent.txt`
- `Comment-et-quand-à-utiliser-sous-agents-IA.txt`
- `Cours-avancé-—-Loop-Agentic-Loop-Engineering.txt`
- `Loop Agentic- Loop Engineering.pdf` — 9 pages, boucle contrôlée / Loop Spec / évaluateur / garde-fous / subjectivité
- `Prompt-engineering-avancé.txt`

## Ce qui change réellement l'architecture Luna

1. **Manager = propriétaire du global.** Les workers ne se transmettent pas la propriété du workflow.
2. **Contrats courts de délégation.** Objectif, scope, fichiers, contraintes, acceptance criteria, checks, output.
3. **Contexte filtré.** Les explorations bruyantes restent dans les workers ; le manager reçoit conclusions et preuves.
4. **Séparation génération / vérification / décision.** Writer ≠ Reviewer ≠ Tester ≠ décideur.
5. **Gates observables.** Git diff, exit codes, tests, findings explicites.
6. **Parallélisme conditionnel.** Read-only largement parallélisable ; writers seulement si scopes réellement indépendants et isolation suffisante.
7. **Boucles bornées.** Le système doit pouvoir dire BLOCKED plutôt que poursuivre indéfiniment.
8. **Pas de mémoire géante.** Stocker seulement l'état durable/nécessaire ; ne pas transformer toutes les traces en contexte actif.
9. **Permissions d'abord.** Les interdictions textuelles sont une couche, pas une barrière.
10. **Prompts compacts.** Les skills/procédures existants doivent rester sources de vérité.

## Éléments explicitement écartés ou downgradés

- Demander/archiver une chaîne de pensée privée : écarté.
- Valeurs numériques présentées dans le projet comme seuils universels de variables/tokens : `NON DOCUMENTÉ` officiellement, donc non utilisées comme lois.
- Configuration Claude/Anthropic copiée vers VS Code : écartée.
- Routeur XOR systématique : non nécessaire pour le coding manager ; le manager peut router dynamiquement.
- Mémoire propriétaire `MEMORY.md` obligatoire : non retenue ; utiliser d'abord primitives VS Code + Git + skills existants.
- Swarm d'agents : non retenu ; quatre rôles suffisent pour la cible.

## Principe de résolution des contradictions

Pour une capacité OpenAI ou VS Code :
`SOURCE_OPENAI / SOURCE_VSCODE actuelle > SOURCE_PROJET > INFÉRENCE`.

Le projet apporte des patterns d'ingénierie ; il ne détermine pas les capacités techniques du produit.
