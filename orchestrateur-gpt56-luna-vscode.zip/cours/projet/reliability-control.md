# Fiabilité et contrôle — savoir utile extrait du projet

## Principe 1 — Une assertion LLM n'est pas une preuve d'exécution

**Principe**  
Le système doit préférer un état observable (exit code, diff, hash, test) à une phrase du modèle.

**Problème traité**  
Faux `DONE`, test « passé » sans commande, écriture partielle ou non relue.

**Application possible à Luna**  
Le Tester rapporte commande + statut + exit code ; le manager n'accepte pas « tests OK » sans trace. Le scope est contrôlé via Git.

**Limite**  
Un test passant ne prouve pas la correction fonctionnelle totale ; il ne prouve que le critère testé.

**Implication pour l'architecture**  
Séparation génération → vérification → décision.

**SOURCE_PROJET**  
- `guide-architecture-multi-agents.md` : pattern write/reread/verify et validations en chaîne.
- `multi_agent_cours.pdf`, pages 1 et 5 : readback critique, anti-patterns et checklist.
- `Cours-avancé-—-Loop-Agentic-Loop-Engineering.txt`

## Principe 2 — Garde-fous bornés et escalade

**Principe**  
Une boucle de correction doit posséder un signal de succès, un nombre de tentatives borné et un état d'escalade.

**Problème traité**  
Agent qui corrige indéfiniment, accumule des modifications ou masque le problème initial.

**Application possible à Luna**  
Après un nombre court de cycles FIX, si le même blocage persiste ou si le scope doit être élargi : `BLOCKED` / décision utilisateur.

**Limite**  
Les valeurs numériques `max_iterations` données dans les cours sont des recommandations de projet, pas des limites officielles OpenAI/VS Code.

**Implication pour l'architecture**  
Architecture proposée : deux cycles de correction par défaut, configurable ; jamais présenté comme une contrainte produit officielle.

**SOURCE_PROJET**  
- `Cours-avancé-—-Loop-Agentic-Loop-Engineering.txt`
- `Loop Agentic- Loop Engineering.pdf`, pages 2–4 : freins d'urgence, stop/escalade.

## Principe 3 — Permissions > texte quand possible

**Principe**  
Les actions sensibles doivent être limitées par l'environnement ou les outils plutôt que seulement par des interdictions rédigées.

**Problème traité**  
Prompt ignoré, instruction contradictoire, modification opportuniste.

**Application possible à Luna**  
Reviewer sans outil d'édition, manager sans edit/terminal, hooks/sandbox/approvals et fichiers protégés.

**Limite**  
Les détails de permissions de `Claude-Code-conçoit-des-agents-IA.txt` sont spécifiques à un autre produit et ne valent pas comme documentation VS Code.

**Implication pour l'architecture**  
Le principe est retenu ; l'implémentation est redéfinie à partir de la documentation VS Code officielle.

**SOURCE_PROJET**  
- `Claude-Code-conçoit-des-agents-IA.txt`
- `Coder-un-module-de-planification-et-de-mémoire-pour-un-agent-IA.txt`
