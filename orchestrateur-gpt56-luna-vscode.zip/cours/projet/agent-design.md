# Conception d'agents — savoir utile extrait du projet

## Principe 1 — Un rôle, une responsabilité identifiable

**Principe**  
Un agent spécialisé doit avoir une responsabilité unique et une frontière claire avec le manager et les autres workers.

**Problème traité**  
Chevauchement de responsabilités, duplication, agents qui prennent des décisions de niveau global.

**Application possible à Luna**  
Séparer Orchestrator / Coder / Reviewer / Tester. Le manager décide ; le Coder modifie ; le Reviewer produit des findings ; le Tester exécute les validations.

**Limite**  
Le projet contient des exemples issus d'autres harnesses et un guide « mono-exécutant LLM ». Ils ne prouvent pas les capacités de VS Code.

**Implication pour l'architecture**  
Conserver seulement quatre rôles de base ; ne pas créer un agent « architect », « planner », « router », « synthesizer » si le manager peut assumer directement ces fonctions.

**SOURCE_PROJET**  
- `guide-architecture-multi-agents.md`
- `multi_agent_cours.pdf`, pages 1–3 : séparation oracle/orchestrateur/routeur/workers/mémoire/validation.
- `Coder-des-agents-IA-etape-par-etape.txt`

## Principe 2 — Le manager garde la propriété globale

**Principe**  
La tâche globale, les dépendances, le passage d'une phase à l'autre et la consolidation doivent rester chez un point de contrôle central.

**Problème traité**  
Chaînes agent→agent où chaque worker étend implicitement le scope ou déclenche la suite sans connaître l'état global.

**Application possible à Luna**  
Le manager reçoit la demande, fixe scope et DONE, délègue, réconcilie les sorties et décide PASS/FIX/BLOCK. Les workers reviennent systématiquement au manager.

**Limite**  
Le fichier `Agentic-worflow.txt` est un exemple médical et ne constitue pas une spécification VS Code ; seule la structure de dépendances est réutilisable.

**Implication pour l'architecture**  
Pas de délégation latérale Coder→Tester→Reviewer ; tous les handoffs critiques repassent par le manager.

**SOURCE_PROJET**  
- `Agentic-worflow.txt`
- `guide-architecture-multi-agents.md`

## Principe 3 — Distinguer règles stables, contrat de tâche et état

**Principe**  
Les règles durables ne doivent pas être confondues avec le scope ponctuel et l'état d'un run.

**Problème traité**  
Prompts gigantesques, informations obsolètes, conflits entre règles et état courant.

**Application possible à Luna**  
- skills existants = procédures/règles spécialisées ;
- `.agent.md` = autorité et frontières du rôle ;
- contrat de délégation = scope courant ;
- Git/tests/findings = état vérifié.

**Limite**  
Les modèles mémoire `MEMORY.md`/`plan.md` proposés par le projet ne sont pas obligatoires dans VS Code et peuvent ajouter de la complexité.

**Implication pour l'architecture**  
Ne pas introduire un sous-système mémoire propriétaire tant que le workflow peut fonctionner avec le contexte de session, les subagents et Git.

**SOURCE_PROJET**  
- `Pourquoi-a-t-on-besoin-de-mémoire-pour-un-agent-IA.txt`
- `Coder-un-module-de-planification-et-de-mémoire-pour-un-agent-IA.txt`
- `Claude-Code-conçoit-des-agents-IA.txt`
