# Orchestration et délégation — savoir utile extrait du projet

## Principe 1 — Dépendances explicites et gates

**Principe**  
Une tâche aval ne démarre que lorsque ses inputs obligatoires sont disponibles et validés.

**Problème traité**  
Review ou tests lancés sur un état incomplet ; résultats consolidés avant fin des writers.

**Application possible à Luna**  
Fan-out de tâches indépendantes → attente des sorties → fan-in → scope audit → review/tests.

**Limite**  
Le guide du projet impose parfois des workflows strictement séquentiels ou un routeur XOR déterministe. Ce n'est pas toujours nécessaire pour du coding multi-agent.

**Implication pour l'architecture**  
Le manager conserve une carte de dépendances, mais choisit dynamiquement séquence ou parallèle.

**SOURCE_PROJET**  
- `Agentic-worflow.txt`
- `guide-architecture-multi-agents.md`
- `multi_agent_cours.pdf`, page 4 : construction par phases et dépendances.

## Principe 2 — Contrat d'exécution atomique

**Principe**  
Une délégation doit définir l'objectif observable, les entrées, les actions autorisées/interdites, le critère d'arrêt et la sortie attendue.

**Problème traité**  
Worker qui interprète « améliore » comme autorisation de refactorer tout le module.

**Application possible à Luna**  
Chaque Coder reçoit un sous-scope borné et retourne seulement ce qui est nécessaire au manager.

**Limite**  
Éviter de transformer ce contrat en micro-workflow figé ; le worker garde la stratégie locale.

**Implication pour l'architecture**  
Standardiser l'enveloppe de délégation, pas les micro-actions.

**SOURCE_PROJET**  
- `Cours-avancé-—-Loop-Agentic-Loop-Engineering.txt`
- `Loop Agentic- Loop Engineering.pdf`, pages 2, 4 et 5 : état, objectif vérifiable, actions, évaluation, guardrails, Loop Spec.
- `Prompt-engineering-avancé.txt`

## Principe 3 — Paralleliser seulement ce qui est réellement indépendant

**Principe**  
Le parallèle est utile quand les tâches sont indépendantes ; les edits couplés ou sur les mêmes fichiers doivent être sérialisés ou isolés.

**Problème traité**  
Conflits de writers, hypothèses divergentes, intégration impossible.

**Application possible à Luna**  
Parallèle : reviews read-only, explorations, coders sur fichiers disjoints. Sérialisation : même fichier, même interface/API, migration partagée.

**Limite**  
Le projet contient des recommandations fondées sur d'autres harnesses ; l'isolation réelle est à déterminer via VS Code officiel.

**Implication pour l'architecture**  
Le parallèle de writers doit être subordonné à une règle de non-chevauchement de scope et, si nécessaire, à des worktrees/sessions séparés.

**SOURCE_PROJET**  
- `Comment-et-quand-à-utiliser-sous-agents-IA.txt`
- `Créer-des-sous-agents-personnalisés.txt`
