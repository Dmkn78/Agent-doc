# 06 — Review et vérification indépendante

## Séparation des responsabilités

### Generation
Coder produit le changement dans un scope donné.

### Verification
- Reviewer : conformité sémantique, architecture, règles, risques, scope logique.
- Tester : preuves d'exécution et état Git.

### Decision
Manager : DONE / FIX_REQUIRED / BLOCKED / UNVERIFIED / PARTIAL.

## Reviewer

Read-only : `read`, `search`.

Entrées minimales :
- task contract ;
- changed files / diff ;
- acceptance criteria ;
- références de rules/skills pertinentes.

Sortie :
```yaml
verdict: PASS | FINDINGS
findings:
  - severity: blocking | major | minor
    file: path
    line: optional
    evidence: constat observable
    rule: critère/règle affecté
    requested_fix: correction attendue
unverified: []
```

Le Reviewer ne corrige jamais silencieusement.

## Tester

Outils : `read`, `search`, `execute`; aucun `edit`.

Sortie par check :
```yaml
command: "..."
status: PASS | FAIL | NOT_RUN | NOT_AVAILABLE
exit_code: integer|null
evidence: extrait court
```

Puis scope audit : changed/untracked files, protected files, verdict.

## Règle de preuve

Un texte « j'ai testé » n'est jamais transformé en PASS. Un PASS nécessite une exécution observée avec résultat.

## Ordre recommandé

1. Coder(s) terminent.
2. Scope audit rapide.
3. Reviewer(s) et Tester(s) peuvent être lancés en parallèle si les tests ne modifient pas de fichiers partagés de manière conflictuelle.
4. Manager réconcilie.
5. Si blocking finding / FAIL : cycle FIX.
6. Re-review ciblée + tests applicables.
