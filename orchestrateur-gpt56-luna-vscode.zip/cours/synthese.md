# Synthèse — construire un excellent orchestrateur autour de GPT-5.6 Luna

## Thèse

La bonne stratégie n'est pas d'augmenter le prompt jusqu'à « simuler Sol ». Elle consiste à réduire la quantité de jugement non vérifié confiée au manager.

## Système recommandé

```text
Luna/Terra Manager
   ├── décide scope / tâches / dépendances
   ├── délègue Coder(s)
   ├── attend fan-in
   ├── délègue Reviewer(s) read-only
   ├── délègue Tester(s) execute + Git
   └── décide DONE/FIX/BLOCK selon preuves
```

## Invariants

1. Manager sans outil d'édition.
2. Workers sans subagents.
3. Coder sans ownership global.
4. Reviewer read-only.
5. Tester sans edit et sans droit d'inventer une commande/résultat.
6. Scope contrôlé par Git, pas seulement le prompt.
7. DONE requiert review + checks applicables + scope PASS.
8. Hors-scope = proposition ou BLOCKED, jamais refactor opportuniste.
9. Contexte minimal et subagents stateless.
10. Hooks utiles mais secondaires car Preview.
11. Writers parallèles uniquement si non-chevauchants ; worktrees séparés pour isolation forte.
12. Skills existants réutilisés après inspection réelle.

## Manager

- **Terra** est recommandé si l'objectif prioritaire est la qualité d'orchestration et si le surcoût est acceptable.
- **Luna** reste une architecture cible viable avec les guardrails ci-dessus et est nettement moins cher en API.

## Limite principale du travail

Les trois skills `coding`, `coding-rules`, `coding-quality` n'étaient pas présents dans le repository accessible. Leur contenu n'a donc pas été inventé. La phase finale contient une procédure de raccordement obligatoire.
