# 08 — Observabilité

## Ce qu'il faut pouvoir reconstruire

Pour chaque `task_id` :
- agent choisi ;
- prompt/contrat de délégation ;
- fichiers lus importants ;
- fichiers revendiqués modifiés ;
- état Git réellement observé ;
- commandes exécutées ;
- exit codes / résultats ;
- findings de review ;
- cycles de correction ;
- décision finale ;
- éléments non vérifiés.

## Sources d'observation VS Code

**DOCUMENTÉ**
- détails des subagents : prompt, tool calls, résultat ;
- sessions/peer chats ;
- commandes et sorties terminal visibles ;
- diff/Source Control ;
- hooks pouvant produire des logs ;
- debug logs du harness lorsqu'activés.

## Politique

Ne jamais demander ni stocker de chaîne de pensée privée.

Un journal d'audit opérationnel peut contenir :
```yaml
task_id: T-01
agent: Coder
scope: [src/a.ts]
tools: [read, search, edit]
changed_files_observed: [src/a.ts]
review: PASS
checks:
  lint: PASS
  typecheck: PASS
unverified: []
final_status: DONE
```

## Persistance

La version minimale n'ajoute pas de DB de logs. Le transcript VS Code + Git + sortie finale du manager suffisent pour l'usage interactif.

Option : hook d'audit append-only vers un fichier non tracké. Ne pas stocker de secrets ni de contenu privé inutile.
