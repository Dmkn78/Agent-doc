# 09 — Failure modes de Luna manager

| failure | cause probable | détection | prévention | récupération |
|---|---|---|---|---|
| scope creep | objectif ambigu / writer trop autonome | Git diff hors allowed_files | contrat scope + edit limité + approvals | rollback changements hors scope, redéléguer |
| refactor opportuniste | modèle optimise au-delà de la demande | Reviewer + diff | règle « proposition, pas modification » | revert ciblé, conserver suggestion séparée |
| mauvaise compréhension | inputs/criteria insuffisants | résultat ne mappe pas aux acceptance criteria | préflight manager | reformuler contrat, nouvelle délégation |
| architecture incohérente | workers modifient des contrats partagés sans coordination | review d'intégration / build | manager propriétaire des dépendances | sérialiser, réconcilier interface puis rework |
| duplication | agents ignorent source de vérité/skills | search/review | références aux skills et code existant | supprimer doublon, consolider |
| violation coding rules | skill non chargé ou conflit de règles | Reviewer/lint | skills canonique + formatter/linter | correction ciblée |
| UI incohérente | writer local ignore patterns existants | visual review/tests | contexte UI pertinent + reviewer | correction / human review |
| faux DONE | manager accepte affirmation sans preuve | absence d'exit code/finding | completion gate | statut UNVERIFIED, lancer Tester |
| tests non exécutés | commande omise/indisponible | NOT_RUN | required_checks explicites | exécuter ou expliquer NOT_AVAILABLE |
| résultat inventé | LLM rapporte un test non observé | aucune invocation execute | evidence over claims | invalider PASS, relancer Tester |
| auto-review complaisante | même contexte/auteur juge son travail | findings anormalement faibles / erreur persistante | Reviewer séparé read-only | second reviewer / human review |
| délégation incorrecte | tâche trop large ou agent inadapté | SCOPE_BLOCKED / faible progrès | contrat atomique + agents whitelist | redécouper |
| contexte insuffisant | worker stateless reçoit peu d'inputs | BLOCKED/mauvaise hypothèse | contrat autosuffisant | enrichir seulement inputs manquants |
| contexte trop chargé | trop de fichiers/logs/règles | dérive, coût, contradictions | progressive disclosure/subagents | nouvelle session/compact, résumé vérifié |
| conflits entre writers | filesystem partagé / fichiers couplés | git conflicts/diff interférent | scopes disjoints ou worktrees | sérialiser/intégrer séparément |
| boucle de correction sans fin | critère de stop flou | mêmes findings répétés | cycles bornés + DONE explicite | BLOCKED / escalade humaine |
| hook contourné/obsolète | feature Preview / tool inputs changés | audit vs Git incohérent | ne pas dépendre du hook seul | désactiver/réviser hook, s'appuyer Git+approvals |
| skill mal assigné | contenu réel non inspecté | comportement redondant/conflictuel | audit des SKILL.md | corriger matrice, supprimer duplication |
