# 11 — Réanalyse obligatoire après recherches

## 1. Rôle exact du manager

Le manager n'est pas un super-Coder. Il possède : compréhension de la demande, scope, décomposition, ordonnancement, sélection des workers, fan-in, décision de correction et verdict final.

## 2. Ce qui reste chez le manager

- normalisation de l'objectif ;
- définition du scope et de DONE ;
- découpage et dépendances ;
- choix parallèle/séquentiel ;
- sélection du contexte nécessaire ;
- décision FIX/PASS/BLOCK ;
- communication finale.

## 3. Ce qui est délégué

- écriture : Coder ;
- critique indépendante : Reviewer ;
- exécution de validations + audit Git : Tester.

## 4. Ce qui doit être déterministe

- fichiers réellement modifiés : Git ;
- exit codes : shell/test runner ;
- lint/typecheck/build/tests : outils projet ;
- protections sensibles : permissions/sandbox/hooks ;
- tool capabilities : custom agents VS Code.

## 5. Nombre de types d'agents nécessaires

Quatre au total : Orchestrator + Coder + Reviewer + Tester. Pas de Planner distinct, car la planification/decomposition est précisément le cœur du rôle manager. Pas de Router distinct ; la décision de routage est dynamique et reste simple.

## 6. Parallélisme

- reviewers : oui ;
- analyses read-only : oui ;
- testers : oui si sans ressources partagées conflictuelles ;
- coders : seulement scopes disjoints ; worktrees séparés pour isolation plus forte.

## 7. Contexte par agent

- Manager : état global compact + sorties des workers.
- Coder : tâche atomique + fichiers/règles nécessaires.
- Reviewer : tâche + diff + rules/criteria, sans justification détaillée du Coder.
- Tester : required_checks + scope contract + état repo.

## 8. Outils

- Manager : agent/read/search.
- Coder : read/search/edit.
- Reviewer : read/search.
- Tester : read/search/execute.

## 9. Empêcher hors scope

Pas une phrase unique. Contrat + tool restriction + approvals + sandbox + Git + reviewer + hook optionnel.

## 10. Détecter faux DONE

DONE impossible tant que les checks requis n'ont pas un statut observable et que review/scope ne sont pas passés.

## 11. Vérifier réellement

Exit code + output + git status/diff + review indépendante.

## 12. Skills existants

Réutilisation exigée mais contenu non accessible ici. Ne pas dupliquer. Sur l'autre PC, localiser les trois SKILL.md et établir la matrice avant activation finale.

## 13. Faiblesses Luna à compenser

- self-debugging plus faible que Terra sur plusieurs evals officielles ;
- long-context moins robuste sur plusieurs tests à grande taille ;
- aucune garantie de scope/completion ;
- risque général d'accepter une sortie plausible comme preuve si le harness ne l'impose pas.

## Architecture retenue après réanalyse

```text
User
  │
  ▼
Orchestrator (Luna cible / Terra option qualité)
  │ owns task + scope + dependency graph
  ├─> Coder(s) — write, no subagents
  │        │
  │        └──── fan-in
  │
  ├─> Reviewer(s) — read-only
  └─> Tester(s) — execute + Git audit, no edit
           │
           ▼
      evidence bundle
           │
           ▼
Orchestrator → DONE | FIX_REQUIRED | BLOCKED | UNVERIFIED | PARTIAL
```

Correction : le manager renvoie les findings précis à un Coder, puis exige une nouvelle vérification applicable. Pas de chaîne libre Coder→Reviewer→Coder sans supervision.
