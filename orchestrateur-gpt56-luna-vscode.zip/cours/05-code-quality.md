# 05 — Qualité de code et réutilisation des skills

## Règle

La qualité ne doit pas être recopiée dans quatre prompts différents.

## Source de vérité

Les skills annoncés par le repository :
- `coding`
- `coding-rules`
- `coding-quality`

n'ont pas pu être localisés dans l'environnement accessible. Leur matrice réelle ne peut donc pas être inventée.

## Matrice provisoire à confirmer après inspection réelle

| Skill | Manager | Coder | Reviewer | Tester | Chargement | Statut |
|---|---:|---:|---:|---:|---|---|
| coding | ? | ? | ? | ? | à déterminer | BLOQUÉ : contenu absent |
| coding-rules | ? | ? | ? | ? | à déterminer | BLOQUÉ : contenu absent |
| coding-quality | ? | ? | ? | ? | à déterminer | BLOQUÉ : contenu absent |

## Méthode de décision à appliquer sur l'autre PC

Pour chaque skill, lire `SKILL.md` et noter :
1. objectif ;
2. conditions d'activation ;
3. outils/scripts ;
4. règles de code ;
5. validations ;
6. chevauchements.

Puis affecter :
- à un rôle si le skill modifie directement son travail ;
- `on-demand` si le contenu est spécifique à certaines tâches ;
- aucun rôle si la responsabilité est déjà couverte par un autre skill plus canonique.

## Heuristique non substitutive

- Un skill d'implémentation devrait normalement concerner Coder.
- Un skill de règles transversales pourrait concerner Coder et Reviewer.
- Un skill de qualité/validation pourrait concerner Reviewer et éventuellement Coder.

Ces trois lignes sont **INFÉRÉES par les noms uniquement** et ne constituent pas la matrice finale.
