# 02 — Context engineering

## Règle centrale

La fenêtre de contexte n'est pas une base de données. Le manager reçoit l'état nécessaire à la prochaine décision, pas toute l'histoire du projet.

## Trois couches de contexte

### A. Contexte stable
- architecture essentielle ;
- conventions globales non déjà automatisées ;
- pointeurs vers skills ;
- fichiers réellement sensibles/protégés.

### B. Contrat de tâche
- goal ;
- scope ;
- allowed_files ;
- protected_files ;
- inputs ;
- constraints ;
- acceptance_criteria ;
- required_checks ;
- expected_output.

### C. État vérifié
- changements Git ;
- findings de review ;
- commandes exécutées et statuts ;
- blocages ;
- décisions déjà prises.

## Progressive disclosure

**SOURCE_VSCODE** — Les skills sont chargés progressivement et VS Code recommande de fournir le contexte progressivement plutôt que de tout injecter.

Application :
- le manager connaît le nom/usage des skills ;
- le Coder charge `coding` / `coding-rules` / `coding-quality` seulement selon leur contenu réel et leur pertinence ;
- les reviewers ne reçoivent pas les longues explications du Coder, seulement le diff/scope/criteria nécessaires.

## Compaction

- Utiliser les subagents pour isoler les étapes bruyantes.
- Pour une conversation manager longue, `/compact` est une primitive VS Code disponible.
- Après un jalon : conserver décision + preuves + prochain état, éliminer les pistes mortes.

## Anti-patterns

- Context dump « au cas où ».
- Réinjecter tout le repo à chaque délégation.
- Donner au Reviewer la justification détaillée du Coder avant sa revue : cela réduit le caractère neuf du regard.
- Utiliser la mémoire ou un résumé comme preuve de tests : seule l'exécution observable vaut preuve.
