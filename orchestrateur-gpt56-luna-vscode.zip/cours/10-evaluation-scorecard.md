# 10 — Scorecard Luna vs Terra pour le rôle de manager

L'échelle qualitative ci-dessous distingue explicitement les preuves. Aucun benchmark privé n'est inventé.

| Critère | Luna | Terra | Statut / base |
|---|---|---|---|
| compréhension de tâche | capable ; pas de benchmark manager dédié trouvé | probablement supérieur sur tâches complexes | INFÉRÉ à partir du positionnement + evals |
| décomposition | capable via agentic coding | avantage plausible | INFÉRÉ |
| respect du scope | aucune garantie produit | aucune garantie produit | NON DOCUMENTÉ |
| délégation | VS Code permet le mécanisme quel que soit le modèle compatible | idem | DOCUMENTÉ VSCODE (mécanisme), pas qualité modèle |
| multi-agent management | pas de benchmark VS Code dédié trouvé | pas de benchmark dédié trouvé | NON DOCUMENTÉ |
| détection/correction d'erreurs | plus faible sur plusieurs evals self-improvement | avantage net | DOCUMENTÉ OPENAI |
| tool use | proche ; Luna légèrement > Terra sur Toolathlon, légèrement < sur AutomationBench | proche | DOCUMENTÉ OPENAI |
| stabilité | pas de métrique manager dédiée | pas de métrique manager dédiée | NON DOCUMENTÉ |
| long context | très variable ; faibles MRCR longues, bon GraphWalks 256K | globalement plus robuste sur les longues tailles publiées | DOCUMENTÉ OPENAI |
| coding | bon | légèrement à modérément supérieur | DOCUMENTÉ OPENAI |
| review | xhigh recommandé par OpenAI API pour review exigeante, mais qualité Luna spécifique non isolée | probablement supérieur | PARTIELLEMENT DOCUMENTÉ + INFÉRÉ |
| coût API | 0,20 / 0,02 / 1,20 $ | 2 / 0,20 / 12 $ | DOCUMENTÉ (input/cached/output par 1M) |
| latence | Luna positionné rapide/abordable ; latence chiffrée non fournie ici | non chiffrée | POSITIONNEMENT / NON DOCUMENTÉ chiffré |

## Mesures officielles sélectionnées

### Coding
- Artificial Analysis Coding Agent Index : Luna 74,6 ; Terra 77,4.
- SWE-Bench Pro : Luna 62,7 ; Terra 63,4.
- Terminal-Bench 2.1 : Luna 84,7 ; Terra 87,4.

### Self-improvement / debugging
- Internal Research Debugging : 50,8 vs 67,8.
- KernelGen : 22,4 vs 49,2.
- PostTrainBench : 29,6 vs 51,5.
- RSI Index : 41,9 vs 56,3.

### Long context
- MRCR 256K–512K : 41,3 vs 89,6.
- MRCR 512K–1M : 41,3 vs 72,5.
- GraphWalks 256K : Luna 81,3 vs Terra 76,9.
- GraphWalks 1M : Luna 51,2 vs Terra 71,2.

## Verdict

### Manager recommandé si qualité d'orchestration prioritaire
**GPT-5.6 Terra**, avec workers Luna.

Raison : les écarts les plus pertinents pour un manager apparaissent sur debugging/self-correction et plusieurs tests long-context, alors que le surcoût du manager peut être concentré sur un seul rôle.

### Manager recommandé si coût strict / architecture Luna imposée
**GPT-5.6 Luna**, mais avec :
- contexte plus fortement réduit ;
- scope Git déterministe ;
- reviewer/tester indépendants ;
- correction bornée ;
- pas de rôle d'éditeur direct pour le manager.

### Responsabilités à ne confier à aucun des deux modèles seuls
- preuve de test ;
- détection exhaustive des fichiers modifiés ;
- protection de fichiers sensibles ;
- décision basée sur commandes réellement exécutées ;
- isolation de filesystem ;
- enforcement de permissions.

Ces responsabilités appartiennent à Git, VS Code permissions/sandbox/hooks, test runner et architecture de tools.
