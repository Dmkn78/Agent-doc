# Inventaire des sources officielles réellement consultées

Recherche effectuée le 2026-08-10. Sources externes limitées à OpenAI et Visual Studio Code conformément à la politique utilisateur.

## OpenAI

1. GPT-5.6 Luna model page  
   https://developers.openai.com/api/docs/models/gpt-5.6-luna
2. GPT-5.6 Terra model page  
   https://developers.openai.com/api/docs/models/gpt-5.6-terra
3. GPT-5.6 Sol model page — référence comparative uniquement  
   https://developers.openai.com/api/docs/models/gpt-5.6-sol
4. GPT-5.6 launch / official evaluations  
   https://openai.com/index/gpt-5-6/
5. Latest model guide / GPT-5.6 prompting & multi-agent API  
   https://developers.openai.com/api/docs/guides/latest-model
6. Reasoning guide  
   https://developers.openai.com/api/docs/guides/reasoning
7. Compaction guide  
   https://developers.openai.com/api/docs/guides/compaction
8. Conversation state guide  
   https://developers.openai.com/api/docs/guides/conversation-state
9. GPT-5.6 system card — consultée pour les limites/comportements, sans extrapoler Sol vers Luna  
   https://openai.com/index/gpt-5-6-system-card/

## Visual Studio Code

1. Custom agents  
   https://code.visualstudio.com/docs/agent-customization/custom-agents
2. Subagents  
   https://code.visualstudio.com/docs/agents/run/subagents
3. Tools with agents  
   https://code.visualstudio.com/docs/agents/run/tools
4. AI features / built-in tool sets  
   https://code.visualstudio.com/docs/agents/reference/ai-features-cheat-sheet
5. Approvals & permissions  
   https://code.visualstudio.com/docs/agents/run/approvals
6. AI security  
   https://code.visualstudio.com/docs/agents/run/security
7. Review/revert code edits  
   https://code.visualstudio.com/docs/agents/run/review-code-edits
8. Agent Skills  
   https://code.visualstudio.com/docs/agent-customization/agent-skills
9. Custom instructions  
   https://code.visualstudio.com/docs/agent-customization/custom-instructions
10. Agent hooks  
    https://code.visualstudio.com/docs/agent-customization/hooks
11. Language models / thinking effort  
    https://code.visualstudio.com/docs/agent-customization/language-models
12. Agent harnesses  
    https://code.visualstudio.com/docs/agents/run/agent-harnesses
13. Context engineering  
    https://code.visualstudio.com/docs/agents/guides/context-engineering
14. VS Code production model comparison blog (coding interaction proxy only)  
    https://code.visualstudio.com/blogs/2026/07/29/mai-code-1-flash

## Règle de lecture

- Une capacité décrite sur OpenAI Responses API n'est pas attribuée automatiquement à VS Code.
- Une fonctionnalité VS Code Preview est marquée comme telle et n'est jamais l'unique garde-fou.
- Toute caractéristique non couverte par ces pages est marquée `NON DOCUMENTÉ`.
