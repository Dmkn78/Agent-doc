# GPT-5.6 Luna — faits officiels utiles à l'architecture

Date de recherche : 2026-08-10

## Positionnement

**FAIT DOCUMENTÉ**
- GPT-5.6 Luna est le membre de la famille GPT-5.6 optimisé pour les workloads sensibles au coût et à fort volume ; OpenAI le positionne approximativement au niveau « nano » de la famille.
- Fenêtre de contexte : 1 050 000 tokens.
- Sortie maximale : 128 000 tokens.
- Knowledge cutoff : 2026-02-16.
- Prix API courant : 0,20 $ / 1M tokens d'entrée, 0,02 $ / 1M cached input, 1,20 $ / 1M tokens de sortie. Les très gros prompts au-delà du seuil documenté ont une tarification majorée.

**SOURCE**
- https://developers.openai.com/api/docs/models/gpt-5.6-luna
- https://openai.com/index/gpt-5-6/

**IMPLICATION POUR L'ARCHITECTURE**
- Luna est économiquement adapté à une population de workers nombreux.
- La grande fenêtre de contexte ne justifie pas de remplir le contexte : les évaluations officielles montrent que la qualité long-context n'est pas uniforme et qu'un manager doit sélectionner le contexte utile.

**INCONNU / NON DOCUMENTÉ**
- Un taux officiel d'hallucination spécifique à Luna pour le coding : NON DOCUMENTÉ.
- Une garantie que Luna respectera toujours le scope d'une modification : NON DOCUMENTÉ.
- Une garantie que Luna saura auto-vérifier correctement son code sans contrôle externe : NON DOCUMENTÉ.

## Coding et agentic behavior

**FAIT DOCUMENTÉ**
Évaluations officielles publiées lors du lancement GPT-5.6 :
- Artificial Analysis Coding Agent Index : Luna 74,6 ; Terra 77,4 ; Sol 80,0.
- SWE-Bench Pro : Luna 62,7 ; Terra 63,4 ; Sol 64,6.
- DeepSWE v1.1 : Luna 67,2 ; Terra 69,6 ; Sol 73,0.
- Terminal-Bench 2.1 : Luna 84,7 ; Terra 87,4 ; Sol 89,8.
- Agents' Last Exam : Luna 50,3 ; Terra 50,4 ; Sol 51,9.
- AutomationBench : Luna 14,9 ; Terra 15,2 ; Sol 16,0.
- Toolathlon : Luna 53,4 ; Terra 53,1 ; Sol 56,5.

**SOURCE**
- https://openai.com/index/gpt-5-6/

**IMPLICATION POUR L'ARCHITECTURE**
- Luna est capable de coding agentique et de tool use, mais les écarts officiels vers Terra/Sol sur plusieurs tâches de coding justifient un système de validation indépendant.
- Toolathlon ne montre pas une domination systématique de Terra ; le problème du manager ne se réduit donc pas à « qui appelle le mieux un outil ».

## Self-correction et tâches longues

**FAIT DOCUMENTÉ**
Évaluations officielles de self-improvement / debugging :
- Internal Research Debugging Eval : Luna 50,8 ; Terra 67,8.
- KernelGen : Luna 22,4 ; Terra 49,2.
- NanoGPT : Luna 1,66 ; Terra 14,5.
- PostTrainBench : Luna 29,6 ; Terra 51,5.
- RSI Index : Luna 41,9 ; Terra 56,3.

Long context officiel :
- MRCR 8-needle, 256K–512K : Luna 41,3 ; Terra 89,6.
- MRCR 8-needle, 512K–1M : Luna 41,3 ; Terra 72,5.
- GraphWalks, 256K : Luna 81,3 ; Terra 76,9.
- GraphWalks, 1M : Luna 51,2 ; Terra 71,2.

**SOURCE**
- https://openai.com/index/gpt-5-6/

**IMPLICATION POUR L'ARCHITECTURE**
- Un Luna manager ne doit pas dépendre d'une mémoire conversationnelle massive ni de son auto-debugging comme unique mécanisme de contrôle.
- Les états intermédiaires doivent être condensés en contrats courts et preuves opérationnelles.
- Les corrections doivent être déclenchées par reviewer/tests/diff plutôt que par « relis-toi ».

## Outils, structured outputs, reasoning

**FAIT DOCUMENTÉ**
- API : streaming, function calling et structured outputs sont supportés.
- API Responses : OpenAI liste notamment web/file search, Code Interpreter, hosted shell, apply patch, Skills, computer use, MCP et tool search comme outils compatibles.
- API GPT-5.6 : reasoning efforts documentés `none`, `low`, `medium`, `high`, `xhigh`, `max` ; un mode `pro` existe dans l'API Responses.

**SOURCE**
- https://developers.openai.com/api/docs/models/gpt-5.6-luna
- https://developers.openai.com/api/docs/guides/latest-model
- https://developers.openai.com/api/docs/guides/reasoning

**IMPLICATION POUR L'ARCHITECTURE**
- Les capacités API ne doivent pas être projetées automatiquement dans VS Code.
- Le choix du reasoning du manager sous VS Code doit être fondé sur ce que le sélecteur VS Code expose réellement.

**INCONNU / NON DOCUMENTÉ**
- Que VS Code expose `xhigh` ou `max` pour le Luna intégré : NON DOCUMENTÉ dans la documentation VS Code consultée.
