# VS Code — Custom Agents

## Fichiers et frontmatter

**FAIT DOCUMENTÉ**
- Un custom agent est défini par un fichier `.agent.md`.
- Emplacement workspace par défaut : `.github/agents/`.
- Le frontmatter peut notamment définir `tools`, `agents`, `model`, `user-invocable`, `disable-model-invocation`, `handoffs` et `hooks` (hooks en Preview).
- Le corps Markdown peut référencer d'autres fichiers par liens Markdown.

**SOURCE**
- https://code.visualstudio.com/docs/agent-customization/custom-agents

**IMPLICATION POUR L'ARCHITECTURE**
- Créer quatre rôles : Orchestrator, Coder, Reviewer, Tester.
- Référencer les skills/règles existants ; ne pas recopier leur contenu.
- Mettre `agents: []` sur les workers pour interdire la délégation en cascade.
- Donner au manager une liste explicite de workers autorisés.

## Least privilege

**FAIT DOCUMENTÉ**
- VS Code recommande de sélectionner seulement les outils pertinents et de donner des outils read-only aux agents sensibles lorsque possible.

**SOURCE**
- https://code.visualstudio.com/docs/agent-customization/custom-agents
- https://code.visualstudio.com/docs/agents/run/tools

**IMPLICATION POUR L'ARCHITECTURE**
- Manager : `agent`, `read`, `search`; pas d'`edit`, pas d'`execute`.
- Coder : `read`, `search`, `edit`; pas de `execute` par défaut.
- Reviewer : `read`, `search` uniquement.
- Tester : `read`, `search`, `execute`; pas d'`edit`.
