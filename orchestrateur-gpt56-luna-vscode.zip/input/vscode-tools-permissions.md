# VS Code — Tools, permissions, sandbox et review

## Outils intégrés vérifiés

**FAIT DOCUMENTÉ**
VS Code documente les tool sets :
- `#agent` : délégation ;
- `#read` : lecture workspace ;
- `#search` : recherche workspace ;
- `#edit` : modifications workspace ;
- `#execute` : terminal/code/tests.

**SOURCE**
- https://code.visualstudio.com/docs/agents/reference/ai-features-cheat-sheet
- https://code.visualstudio.com/docs/agents/run/tools

## Permissions

**FAIT DOCUMENTÉ**
- VS Code propose des niveaux de permission/approbation.
- Bypass approvals / global auto-approve et Autopilot réduisent les confirmations.
- Les commandes terminal peuvent être auto-approuvées de façon granulaire.
- La détection/auto-approbation des commandes terminal est décrite comme best-effort ; des constructions de shell peuvent contourner une classification naïve.
- Le sandbox terminal, lorsqu'il est disponible, peut restreindre lecture/écriture réseau/fichiers au niveau OS (Preview, plateformes supportées indiquées par VS Code).

**SOURCE**
- https://code.visualstudio.com/docs/agents/run/approvals
- https://code.visualstudio.com/docs/agents/run/security

**IMPLICATION POUR L'ARCHITECTURE**
- Ne pas utiliser Bypass/Autopilot comme défaut.
- Utiliser le sandbox lorsqu'il est disponible pour les agents qui exécutent des commandes.
- Les permissions textuelles seules ne constituent pas une barrière de sécurité.

## Diff et preuve des changements

**FAIT DOCUMENTÉ**
- VS Code permet d'inspecter les changements générés et d'utiliser Source Control/diff.
- La vue de changements du chat couvre les modifications faites par les outils d'édition, mais pas nécessairement les fichiers modifiés indirectement par des commandes terminal.

**SOURCE**
- https://code.visualstudio.com/docs/agents/run/review-code-edits

**IMPLICATION POUR L'ARCHITECTURE**
- Le gate de scope doit utiliser Git (`git status --porcelain`, `git diff --name-only`) après les commandes, pas seulement la vue Changes du chat.
