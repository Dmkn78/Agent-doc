# OpenAI — fiabilité, vérification et contexte

## Self-verification

**FAIT DOCUMENTÉ**
- Les évaluations officielles de self-improvement/debugging montrent Luna nettement derrière Terra sur plusieurs tâches.

**SOURCE**
- https://openai.com/index/gpt-5-6/

**IMPLICATION POUR L'ARCHITECTURE**
- Une déclaration du writer (« c'est corrigé », « les tests passent ») n'est pas un signal de validation suffisant.
- Séparer génération, vérification et décision.

## Long context

**FAIT DOCUMENTÉ**
- La famille expose ~1M de contexte.
- Les évaluations long-context publiées ne sont pas uniformes et peuvent fortement varier selon la tâche et le modèle.

**SOURCE**
- https://developers.openai.com/api/docs/models/gpt-5.6-luna
- https://openai.com/index/gpt-5-6/

**IMPLICATION POUR L'ARCHITECTURE**
- Le contexte maximal est une capacité, pas une recommandation de remplissage.
- Maintenir un état compact : scope, dépendances, preuves, findings, décisions, pas l'historique complet des explorations.

## Compaction et état de conversation

**FAIT DOCUMENTÉ — API**
- OpenAI documente la compaction de contexte pour les workloads longs dans l'API et recommande de compacter après des jalons significatifs plutôt que d'accumuler des traces obsolètes.

**SOURCE**
- https://developers.openai.com/api/docs/guides/compaction
- https://developers.openai.com/api/docs/guides/conversation-state

**IMPLICATION POUR L'ARCHITECTURE**
- Principe transférable : conserver les résultats nécessaires, éliminer le bruit des tentatives échouées.
- Mécanisme VS Code : utiliser ses propres sessions/subagents et `/compact` lorsqu'il est disponible ; ne pas confondre avec l'API OpenAI.

## Hallucinations

**INCONNU / NON DOCUMENTÉ**
- Taux officiel de faux résultats de tests inventés par Luna : NON DOCUMENTÉ.
- Taux officiel de scope creep de Luna : NON DOCUMENTÉ.

**IMPLICATION POUR L'ARCHITECTURE**
- Les protections sont conçues comme une réponse de sûreté à l'incertitude, pas comme une correction d'un benchmark hallucination inventé.
