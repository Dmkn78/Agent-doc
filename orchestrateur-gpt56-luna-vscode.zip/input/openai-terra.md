# GPT-5.6 Terra — alternative de manager

Date de recherche : 2026-08-10

## Positionnement et coût

**FAIT DOCUMENTÉ**
- GPT-5.6 Terra équilibre intelligence et coût et est positionné approximativement au niveau « mini ».
- Contexte : 1 050 000 tokens ; sortie max : 128 000 ; cutoff 2026-02-16.
- Prix API courant : 2 $ / 1M input, 0,20 $ cached input, 12 $ / 1M output.

**SOURCE**
- https://developers.openai.com/api/docs/models/gpt-5.6-terra

**IMPLICATION POUR L'ARCHITECTURE**
- Terra coûte environ 10× Luna aux tarifs API courants. L'utiliser uniquement comme manager peut rester rationnel si le nombre d'appels manager est faible par rapport aux workers, mais cette conclusion de coût total dépend de la charge réelle : INFÉRÉ.

## Avantage potentiel comme orchestrateur

**FAIT DOCUMENTÉ**
- Les scores de coding officiels sont en général supérieurs à Luna, mais l'écart est modéré sur SWE-Bench Pro et plus visible sur d'autres évaluations.
- Les évaluations officielles de self-improvement/debugging montrent des écarts importants en faveur de Terra.
- Plusieurs évaluations long-context montrent des écarts importants en faveur de Terra, avec une exception notable où Luna est supérieur sur GraphWalks 256K.

**SOURCE**
- https://openai.com/index/gpt-5-6/

**IMPLICATION POUR L'ARCHITECTURE**
- Pour un rôle de manager qui doit diagnostiquer, réconcilier des findings et garder un état global, Terra présente un avantage significatif documenté.
- Cet avantage ne dispense pas de review, tests, contrôle Git, permissions ou scope contracts.

## Compatibilité avec des workers Luna dans VS Code

**FAIT DOCUMENTÉ — VSCODE**
- Un subagent ne peut pas utiliser un modèle d'un tier de coût supérieur à celui du modèle principal ; sinon l'invocation ne s'exécute pas.

**SOURCE**
- https://code.visualstudio.com/docs/agents/run/subagents

**IMPLICATION POUR L'ARCHITECTURE**
- Un manager Terra peut utiliser des workers Luna (tier inférieur), sous réserve que ces modèles soient disponibles dans l'environnement VS Code concerné.
- L'inverse, manager Luna demandant Terra subagent, est à éviter car la restriction de tier peut empêcher l'exécution.

**INCONNU / NON DOCUMENTÉ**
- L'identifiant littéral exact à écrire dans `model:` pour Luna/Terra dans toutes les installations VS Code : NON DOCUMENTÉ de façon stable dans les pages consultées. Utiliser l'éditeur Customizations / model picker pour écrire la valeur réellement proposée.
