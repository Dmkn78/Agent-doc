# OpenAI — comportement agentique pertinent

## Agent loop et tool use

**FAIT DOCUMENTÉ**
- Les modèles GPT-5.6 peuvent utiliser des outils et être utilisés dans des systèmes agentiques.
- OpenAI documente un multi-agent beta dans la Responses API où GPT-5.6 peut coordonner des subagents.

**SOURCE**
- https://developers.openai.com/api/docs/guides/latest-model
- https://developers.openai.com/api/docs/guides/reasoning

**IMPLICATION POUR L'ARCHITECTURE**
- La possibilité API démontre que la famille sait participer à une orchestration multi-agent.
- Elle ne prouve pas que les primitives et limites sont les mêmes dans VS Code. L'architecture VS Code doit utiliser les primitives VS Code documentées (`.agent.md`, subagents, outils, hooks, sessions).

## Autonomie et boundaries

**FAIT DOCUMENTÉ**
OpenAI recommande de préciser explicitement :
- les actions locales sûres et dans le scope ;
- les actions externes/destructives/coûteuses ;
- les extensions de scope nécessitant une autorisation ;
- les critères de succès et les déclencheurs de clarification.
OpenAI recommande d'éviter de répéter ces mêmes règles de permission de multiples façons.

**SOURCE**
- https://developers.openai.com/api/docs/guides/latest-model

**IMPLICATION POUR L'ARCHITECTURE**
- Le prompt manager doit définir autorité, limites, validation et scope une fois, de façon compacte.
- Les restrictions réellement exécutables doivent être déplacées vers outils/permissions/hooks/tests/Git plutôt que multipliées en texte.

## Subagents

**FAIT DOCUMENTÉ**
- OpenAI documente les subagents au niveau Responses API pour GPT-5.6.

**INCONNU / NON DOCUMENTÉ**
- Que ce mécanisme API soit celui utilisé par VS Code pour ses subagents : NON DOCUMENTÉ ; VS Code dispose de son propre harness et de sa propre documentation.
