# VS Code — Skills et custom instructions

## Agent Skills

**FAIT DOCUMENTÉ**
- VS Code découvre les skills dans des emplacements tels que `.github/skills/`, `.claude/skills/`, `.agents/skills/`; des emplacements supplémentaires peuvent être configurés avec `chat.agentSkillsLocations`.
- Un skill contient un `SKILL.md` avec `name` et `description`.
- Les skills sont chargés progressivement : métadonnées d'abord, corps lorsqu'il devient pertinent, ressources à la demande.
- `context: fork` est un mécanisme expérimental d'isolation de skill.

**SOURCE**
- https://code.visualstudio.com/docs/agent-customization/agent-skills

**IMPLICATION POUR L'ARCHITECTURE**
- Conserver `coding`, `coding-rules`, `coding-quality` comme sources de vérité et les faire découvrir par VS Code à leur emplacement réel.
- Le chargement progressif répond au besoin de context minimization.

## Instructions

**FAIT DOCUMENTÉ**
- `.github/copilot-instructions.md` et `AGENTS.md` peuvent fournir des instructions workspace.
- Plusieurs fichiers d'instructions applicables sont combinés sans ordre spécifique garanti.
- VS Code recommande des instructions concises, focalisées sur les règles non évidentes ; ne pas répéter ce qu'un linter/formatter vérifie déjà.

**SOURCE**
- https://code.visualstudio.com/docs/agent-customization/custom-instructions

**IMPLICATION POUR L'ARCHITECTURE**
- Éviter de disperser des invariants contradictoires dans plusieurs always-on files.
- Utiliser un seul petit fichier global uniquement si un invariant s'applique réellement à tous les agents.
- Les règles de coding doivent rester dans les skills existants si elles y vivent déjà.

## Inspection réelle des skills demandés

**ÉTAT**
- Les fichiers réels `coding`, `coding-rules`, `coding-quality` n'ont pas été trouvés dans le repository monté sous `/mnt/data`, ni dans les emplacements locaux accessibles recherchés, ni dans la File Library consultée.

**CONSÉQUENCE**
- Leur contenu réel, responsabilités et chevauchements : NON INSPECTÉS.
- Toute matrice d'affectation prétendant se baser sur leur contenu serait inventée.
- L'architecture fournit donc une procédure de raccordement manuelle à exécuter dès que leur chemin réel est disponible.
