# OpenAI — prompting GPT-5.6 pour agents de coding

## Prompts plus courts, outcome-first

**FAIT DOCUMENTÉ**
- OpenAI indique que GPT-5.6 comprend mieux l'intention et nécessite moins de micro-procédures que des générations précédentes.
- Des configurations internes de coding-agent avec des system prompts plus légers ont amélioré les scores et réduit les tokens/coûts dans les évaluations rapportées par OpenAI ; OpenAI présente ces résultats comme directionnels et recommande d'évaluer sur son propre workload.

**SOURCE**
- https://developers.openai.com/api/docs/guides/latest-model

**IMPLICATION POUR L'ARCHITECTURE**
- Le manager ne doit pas contenir une SOP gigantesque décrivant chaque mouvement.
- Il doit contenir : mission, autorité, invariants, scope, politique de délégation, critères de validation et statuts de fin.
- Les procédures de coding existantes doivent rester dans les skills plutôt que copiées dans chaque agent.

## Reasoning effort

**FAIT DOCUMENTÉ — API**
- `none`, `low`, `medium`, `high`, `xhigh`, `max` sont documentés pour GPT-5.6 dans l'API.
- OpenAI associe `medium` à du coding agentique/delegation longue, `high` à debugging/planning complexe, `xhigh` aux tâches agentiques longues/code review exigeante et `max` aux tâches les plus complexes.
- Les reasoning tokens ne sont pas visibles comme chaîne de pensée et consomment du contexte / de la sortie facturée.

**SOURCE**
- https://developers.openai.com/api/docs/guides/reasoning
- https://developers.openai.com/api/docs/guides/latest-model

**IMPLICATION POUR L'ARCHITECTURE**
- Côté API, un manager complexe bénéficierait logiquement d'un effort élevé.
- Côté VS Code, ne configurer que le niveau réellement visible dans le model picker.

## Structured outputs

**FAIT DOCUMENTÉ**
- Structured Outputs sont supportés par Luna/Terra via API.

**IMPLICATION POUR L'ARCHITECTURE**
- Les contrats inter-agents peuvent être structurés conceptuellement, mais un `.agent.md` VS Code n'est pas automatiquement un endpoint Structured Outputs. Utiliser des blocs Markdown/JSON courts comme protocole humain-machine, sans prétendre à une validation JSON native si le harness ne la documente pas.
