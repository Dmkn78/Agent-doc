# VS Code — contexte, sessions et worktrees

## Context engineering

**FAIT DOCUMENTÉ**
- VS Code recommande de commencer par un contexte projet concis, puis de fournir progressivement les détails nécessaires plutôt que de tout charger.
- Des sessions séparées servent à éviter le mélange de contextes ; les subagents offrent une isolation pour les tâches déléguées.
- `/compact` existe dans VS Code pour condenser une conversation longue.

**SOURCE**
- https://code.visualstudio.com/docs/agents/guides/context-engineering
- https://code.visualstudio.com/docs/agents/reference/ai-features-cheat-sheet

**IMPLICATION POUR L'ARCHITECTURE**
- Le manager reçoit un état global compact ; les workers reçoivent des contrats de tâche atomiques.
- Les résultats intermédiaires bruyants restent chez le worker ; seule une sortie structurée revient au manager.

## Agent host et worktrees

**FAIT DOCUMENTÉ**
- Le harness orchestre outils, contexte et changements.
- Des sessions Agent Host peuvent travailler sur le dossier courant ou sur un Git worktree isolé.
- Les chats d'une même session Agent Host partagent le même dossier/worktree ; VS Code recommande des sessions/worktrees séparés lorsque des tâches parallèles ne doivent pas changer les mêmes fichiers.
- Les worktrees isolent le code mais ne constituent pas une frontière de sécurité OS.

**SOURCE**
- https://code.visualstudio.com/docs/agents/run/agent-harnesses
- https://code.visualstudio.com/docs/agents/run/agent-sessions

**IMPLICATION POUR L'ARCHITECTURE**
- Plusieurs writers dans le même parent ne sont pas fortement isolés par filesystem.
- Pour des écritures parallèles à risque de conflit, utiliser des sessions/worktrees séparés puis intégrer explicitement.
