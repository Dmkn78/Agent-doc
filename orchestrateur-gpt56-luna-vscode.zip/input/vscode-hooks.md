# VS Code — Agent Hooks

## Capacités

**FAIT DOCUMENTÉ**
- Les hooks sont en Preview.
- Événements documentés : SessionStart, UserPromptSubmit, PreToolUse, PostToolUse, PreCompact, SubagentStart, SubagentStop, Stop.
- Les hooks workspace peuvent vivre sous `.github/hooks/*.json`.
- `PreToolUse` peut retourner une décision `allow`, `ask` ou `deny` pour un tool call et une raison.
- Les hooks reçoivent un JSON structuré incluant session/cwd/event et, selon l'événement, le tool name et ses inputs.
- VS Code recommande de protéger les scripts de hooks eux-mêmes contre les modifications automatiques.

**SOURCE**
- https://code.visualstudio.com/docs/agent-customization/hooks

**IMPLICATION POUR L'ARCHITECTURE**
- Un hook peut fournir une seconde ligne de défense déterministe pour bloquer commandes destructrices / fichiers statiquement protégés et produire un audit.
- Comme la fonctionnalité est Preview et que les noms/inputs de tools peuvent évoluer, le hook ne doit pas être l'unique mécanisme de contrôle du scope.
- Gate principal : Git diff + reviewer/tester + permissions.
