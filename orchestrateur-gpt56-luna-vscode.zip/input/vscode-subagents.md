# VS Code — Subagents

## Isolation de contexte et caractère stateless

**FAIT DOCUMENTÉ**
- Un subagent travaille dans un contexte séparé et renvoie son résultat au parent.
- L'invocation est stateless : le parent ne peut pas reprendre le même subagent dans un tour suivant. Le prompt de délégation doit donc contenir tout le contexte nécessaire et le format de sortie attendu.
- Des outils comme les questions de clarification/todos ne sont pas disponibles à un subagent dans ce cadre.

**SOURCE**
- https://code.visualstudio.com/docs/agents/run/subagents

**IMPLICATION POUR L'ARCHITECTURE**
- Le contrat de délégation doit être autosuffisant et court.
- Si un worker manque d'information, il retourne un état bloqué au manager au lieu d'improviser.

## Restriction et modèles

**FAIT DOCUMENTÉ**
- `agents:` peut limiter les subagents invocables ; les noms sont exacts/case-sensitive.
- L'ordre de priorité du modèle est : invocation explicite, modèle configuré sur le custom agent, modèle du parent.
- Un subagent ne peut pas demander un modèle d'un tier de coût supérieur au parent.
- Les subagents imbriqués sont désactivés par défaut ; si activés, la profondeur maximale documentée est 5.

**SOURCE**
- https://code.visualstudio.com/docs/agents/run/subagents

**IMPLICATION POUR L'ARCHITECTURE**
- Garder les subagents imbriqués désactivés.
- Terra manager + Luna workers est la direction de tier compatible.
- Luna manager + Terra worker est une mauvaise topologie.

## Parallelisme

**FAIT DOCUMENTÉ**
- VS Code documente l'usage de subagents parallèles pour analyse/review et un pattern coordinator/worker.

**IMPLICATION POUR L'ARCHITECTURE**
- Paralléliser les reviewers read-only et les analyses indépendantes.
- Pour des writers, la séparation de contexte n'est pas une isolation du système de fichiers.

**INCONNU / NON DOCUMENTÉ**
- Un filesystem isolé par subagent dans une même session : NON DOCUMENTÉ.
