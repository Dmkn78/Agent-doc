# VS Code — modèles et thinking effort

## Sélection de modèle

**FAIT DOCUMENTÉ**
- VS Code dispose d'un model picker et permet de sélectionner un thinking effort lorsque le modèle/provider l'expose.
- La documentation montre des niveaux tels que None, Low, Medium, High comme exemples ; la liste exacte dépend du modèle/provider.
- L'ancien setting global de Responses API reasoning effort est déprécié au profit du sélecteur de modèle.
- Un custom agent peut déclarer un `model`, ou hériter du modèle choisi dans le picker s'il est omis.

**SOURCE**
- https://code.visualstudio.com/docs/agent-customization/language-models
- https://code.visualstudio.com/docs/agent-customization/custom-agents

**IMPLICATION POUR L'ARCHITECTURE**
- Pour le manager Luna : choisir le niveau le plus élevé réellement visible dans le VS Code de l'utilisateur.
- Ne pas écrire `max`, `xhigh` ou `extra-high` dans l'architecture VS Code sans preuve que le provider sélectionné les expose.

**INCONNU / NON DOCUMENTÉ**
- La documentation VS Code consultée ne garantit pas que GPT-5.6 Luna intégré expose `xhigh` ou `max`.
- Formulation de configuration retenue : `NIVEAU_MAXIMAL_DISPONIBLE À CONFIGURER SELON VSCODE`.
